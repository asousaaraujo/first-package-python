def multiply(x: int, y: int) -> int:
    return x * y
