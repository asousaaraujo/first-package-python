def divide(x: int, y: int) -> int:
    return x // y
