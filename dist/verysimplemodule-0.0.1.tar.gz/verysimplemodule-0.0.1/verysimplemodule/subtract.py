def subtract(x: int, y: int) -> int:
    return x - y
